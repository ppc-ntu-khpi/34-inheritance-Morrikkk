# Практична робота "Реалізація успадкування"

![](https://github.com/ppc-ntu-khpi/34-inheritance-20sergejka02/blob/master/images/2.jpg)

![](https://github.com/ppc-ntu-khpi/34-inheritance-20sergejka02/blob/master/images/1.png)

[![Gitter](https://badges.gitter.im/PPC-SE-2020/OOP.svg)](https://gitter.im/PPC-SE-2020/OOP?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
