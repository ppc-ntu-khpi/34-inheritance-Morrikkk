package domain;

public class Predator extends Animal
{
    public void hunt()
    {
        System.out.println("Predator is hunting;");
    }
}
