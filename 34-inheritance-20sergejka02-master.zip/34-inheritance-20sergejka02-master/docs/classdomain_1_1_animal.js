var classdomain_1_1_animal =
[
    [ "Animal", "classdomain_1_1_animal.html#acfbf1405e335fb7887eba1f22cf484c2", null ],
    [ "eat", "classdomain_1_1_animal.html#aeb4cdcb2e2faa803e125dea86486e474", null ],
    [ "speak", "classdomain_1_1_animal.html#a0070dca2022620de6da5c005e04609a6", null ],
    [ "toString", "classdomain_1_1_animal.html#a1b29e1c4522c9593ac169ea0b113fa07", null ],
    [ "name", "classdomain_1_1_animal.html#aa404f820cb6a0fdfb51dc488a8c9f871", null ],
    [ "weight", "classdomain_1_1_animal.html#ac1add8294c414ae708ecc0b04878784b", null ]
];