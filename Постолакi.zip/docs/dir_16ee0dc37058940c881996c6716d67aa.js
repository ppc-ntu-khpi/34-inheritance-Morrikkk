var dir_16ee0dc37058940c881996c6716d67aa =
[
    [ "Animal.java", "_animal_8java.html", [
      [ "Animal", "classdomain_1_1_animal.html", "classdomain_1_1_animal" ]
    ] ],
    [ "Dog.java", "_dog_8java.html", [
      [ "Dog", "classdomain_1_1_dog.html", "classdomain_1_1_dog" ]
    ] ],
    [ "Predator.java", "_predator_8java.html", [
      [ "Predator", "classdomain_1_1_predator.html", "classdomain_1_1_predator" ]
    ] ]
];