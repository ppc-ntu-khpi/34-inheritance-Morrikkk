var searchData=
[
  ['hunt_6',['hunt',['../classdomain_1_1_dog.html#a5d7002227dff72e55514811e52a4bce5',1,'domain.Dog.hunt()'],['../classdomain_1_1_predator.html#ad00b41c1e8b3652e62fe8f365d3a737a',1,'domain.Predator.hunt()']]]
];
