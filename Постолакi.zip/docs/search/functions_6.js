var searchData=
[
  ['speak_34',['speak',['../classdomain_1_1_animal.html#a0070dca2022620de6da5c005e04609a6',1,'domain.Animal.speak()'],['../classdomain_1_1_dog.html#ab8719e57aadd20ab1ad0c388f547dd49',1,'domain.Dog.speak()']]]
];
